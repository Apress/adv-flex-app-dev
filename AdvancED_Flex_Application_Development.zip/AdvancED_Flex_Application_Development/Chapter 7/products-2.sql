-- phpMyAdmin SQL Dump
-- version 2.7.0-pl2
-- http://www.phpmyadmin.net
-- 
-- Host: localhost
-- Generation Time: May 05, 2007 at 11:37 AM
-- Server version: 5.0.19
-- PHP Version: 5.1.6
-- 
-- Database: `foed8962_products`
-- 

-- --------------------------------------------------------

-- 
-- Table structure for table `products`
-- 

CREATE TABLE `products` (
  `product_id` int(10) NOT NULL auto_increment,
  `product_name` varchar(64) default NULL,
  `product_desc` varchar(255) default NULL,
  `product_price` decimal(10,2) default NULL,
  `product_rating` int(1) default NULL,
  `product_img` varchar(64) default NULL,
  PRIMARY KEY  (`product_id`),
  FULLTEXT KEY `product_name` (`product_name`,`product_desc`)
) ENGINE=MyISAM DEFAULT CHARSET=latin1 AUTO_INCREMENT=21 ;

-- 
-- Dumping data for table `products`
-- 

INSERT INTO `products` VALUES (1, 'Sand People Figurines', 'this is a great collectible item', 24.99, 5, 'assets/images/placeholder.png');
INSERT INTO `products` VALUES (2, 'Star Wars Collector Mug', 'a long time ago, in a galaxy far, far away some people set their sights on the stars...', 199.99, 5, 'assets/images/placeholder.png');
INSERT INTO `products` VALUES (3, 'Xbox 720', 'double the pleasure, double the fun', 999.99, 4, 'assets/images/placeholder.png');
INSERT INTO `products` VALUES (4, 'Magic Soap', 'keeps u clean', 9.99, 3, 'assets/images/placeholder.png');
INSERT INTO `products` VALUES (5, 'Fire', 'life just would not be the same without it', 0.00, 5, 'assets/images/placeholder.png');
INSERT INTO `products` VALUES (6, 'OSX 10.5 Complete Walkthrough', 'learn the ins and outs of Apple''s latest version of its operating system', 39.99, 2, 'assets/images/placeholder.png');
INSERT INTO `products` VALUES (7, 'Flexible Thinking', 'learn proven methods for rapid development using the Flex framework', 49.99, 2, 'assets/images/placeholder.png');
INSERT INTO `products` VALUES (8, 'Pro Tools 7 LE', 'one of the best DAWs around. this is the M-Powered edition...', 249.99, 5, 'assets/images/placeholder.png');
INSERT INTO `products` VALUES (9, 'Magic Shampoo', 'makes dandruff disappear', 10.99, 4, 'assets/images/placeholder.png');
INSERT INTO `products` VALUES (10, 'Holograms in 10 minutes', 'learn how to create realistic holograms in the comfort of your own home using materials you can find around the house. NOTE: this method is not sanctioned by any terrestrial government...', 769.99, 1, 'assets/images/placeholder.png');
INSERT INTO `products` VALUES (11, 'Star Wars Saga DVD', 'the only place to get the entire epic digitally remastered and on one DVD', 89.99, 5, 'assets/images/placeholder.png');
INSERT INTO `products` VALUES (12, 'Wonder Wash', 'wonder wash is terrific because you can wash anything without using water...', 19.99, 2, 'assets/images/placeholder.png');
INSERT INTO `products` VALUES (13, 'Inside Flex 3', 'get a sneak peak at what''s under the hood of the next incarnation of Adobe''s incredible framework...', 29.99, 2, 'assets/images/placeholder.png');
INSERT INTO `products` VALUES (14, 'Flash CS3 for Developers', 'get up to speed with proven workflows and design patterns for developers working in the Flash universe...', 34.99, 3, 'assets/images/placeholder.png');
INSERT INTO `products` VALUES (15, 'Reason 3 Lightspeed', 'see how to easily and effectively use this software sequencer to create compelling sonic landscapes for your Web 2.0 applications', 59.99, 3, 'assets/images/placeholder.png');
INSERT INTO `products` VALUES (16, 'Building a Server Cluster', 'shows you how to create a server farm using those old computers you have sitting around the house.', 29.99, 2, 'assets/images/placeholder.png');
INSERT INTO `products` VALUES (17, 'Beyond the Web', 'shows you how to take your applications beyond the web with the help of Adobe''s Apollo.', 39.99, 2, 'assets/images/placeholder.png');
INSERT INTO `products` VALUES (18, 'Water', 'it''s the source of life and it tastes good too!', 0.00, 5, 'assets/images/placeholder.png');
INSERT INTO `products` VALUES (19, 'Dragon Ball Z: The Lost Episodes', 'this 10-DVD set gives DBZ fans access to the episodes that were never aired anywhere. also includes commentary by DBZ creator, Akira Toriyama.', 99.99, 5, 'assets/images/placeholder.png');
INSERT INTO `products` VALUES (20, 'The Wheel', 'details why round was the only way to go', 24.99, 5, 'assets/images/placeholder.png');
