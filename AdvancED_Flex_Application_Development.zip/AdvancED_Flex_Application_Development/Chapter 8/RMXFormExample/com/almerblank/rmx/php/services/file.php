<?php
/*
 * Created on Jun 12, 2007
 *
 * To change the template for this generated file go to
 * Window - Preferences - PHPeclipse - PHP - Code Templates
 */
 
 
 	class Members {
 		
 		var $username;
 		var $password;
 		var $email;
 		 		
 		function addMember($memberInfo)
 		{
 			$this->username = $memberInfo["username"];
 			$this->password = $memberInfo["password"];
 			$this->email = $memberInfo["email"];



 			
 		}
 		
 		
 		
 		
 		
 		
 	}
 
 
?>
